
let details = [
    {
    name: "Jonny",
    age: 32,
    country: "USA",
    hobbies:"Gaming , Cricket"
    },
    
    {
        name : "Kim",
        age : 26,
        country : "England",
        hobbies :"Dancing , Acting"


    },

    {
        name : "Leo",
        age : 45,
        country : "Japan",
        hobbies :"Cricket , Wrestling"

    },

    {
        name : "Kate",
        age : 22,
        country : "Russia",
        hobbies :"Reading"

    },

    {
        name : "Rahul",
        age : 69,
        country : "India",
        hobbies :"Writing"

    },

]
console.log(details[0])
console.log(details[1])
console.log(details[2])
console.log(details[3])
console.log(details[4])

console.log("People with age less than 30 are::")
for(let i=0;i<5;i++)
{
  if(details[i].age <=30)
   {
    console.log(details[i])    
   }

}

console.log("People with Country as India are::")
for(let i=0;i<5;i++)
{
  if(details[i].country =="India")
   {
    console.log(details[i])    
   }

}