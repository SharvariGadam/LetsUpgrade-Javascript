function copyname(){
    const ele=document.getElementsByClassName("name")
    const ele1=document.getElementsByClassName("name1")
    ele1[0].value=ele[0].value
  
}